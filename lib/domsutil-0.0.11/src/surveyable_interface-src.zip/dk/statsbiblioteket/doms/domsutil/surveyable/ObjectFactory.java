
package dk.statsbiblioteket.doms.domsutil.surveyable;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the dk.statsbiblioteket.doms.domsutil.surveyable package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Severity_QNAME = new QName("http://surveyable.domsutil.doms.statsbiblioteket.dk/", "severity");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: dk.statsbiblioteket.doms.domsutil.surveyable
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetStatusResponse }
     * 
     */
    public GetStatusResponse createGetStatusResponse() {
        return new GetStatusResponse();
    }

    /**
     * Create an instance of {@link StatusMessage }
     * 
     */
    public StatusMessage createStatusMessage() {
        return new StatusMessage();
    }

    /**
     * Create an instance of {@link GetStatusSince }
     * 
     */
    public GetStatusSince createGetStatusSince() {
        return new GetStatusSince();
    }

    /**
     * Create an instance of {@link Status }
     * 
     */
    public Status createStatus() {
        return new Status();
    }

    /**
     * Create an instance of {@link GetStatus }
     * 
     */
    public GetStatus createGetStatus() {
        return new GetStatus();
    }

    /**
     * Create an instance of {@link GetStatusSinceResponse }
     * 
     */
    public GetStatusSinceResponse createGetStatusSinceResponse() {
        return new GetStatusSinceResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Severity }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://surveyable.domsutil.doms.statsbiblioteket.dk/", name = "severity")
    public JAXBElement<Severity> createSeverity(Severity value) {
        return new JAXBElement<Severity>(_Severity_QNAME, Severity.class, null, value);
    }

}
